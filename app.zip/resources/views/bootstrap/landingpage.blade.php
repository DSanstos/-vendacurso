@php
$sitename = "Laravel FullStack";
use App\Models\usuariosModel;
use App\Models\LinksPagModel;
$reservas = usuariosModel::count();
$inscritos = LinksPagModel::where("pago", true)->count();
//$inscritos = 1; //remover ou comentar
if($inscritos > 90){
        $classBadge = "danger";
    } else {
        $classBadge = "success";
    };
@endphp
@extends('bootstrap.model')
@section('headpage')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style type="text/css">
body { 
  background: url(fundo.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
</style>
@endsection
@if(isset($error))
    {{ implode('', $SESSION["error"]) }}
@endif
<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
      <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
        <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
        <span class="fs-4 text-white">{{$sitename}}</span>
      </a>

      <ul class="nav nav-pills">
        @if($inscritos != 0)
        <li class="nav-item"><a href="#" class="nav-link" aria-current="page">
            Inscritos - <span class="badge text-bg-{{$classBadge}}">{{$inscritos}}</span> de 100</a></li>
        @endif
        @if($reservas != 0)
        <li class="nav-item"><a href="#" class="nav-link" aria-current="page">
            Reservas - <span class="badge text-bg-danger">{{$reservas}}</span></a></li>
        @endif
        <li class="nav-item"><a href="/beneficios" class="nav-link">Benefícios</a></li>
        <li class="nav-item"><a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal" class="nav-link">Reservar Vaga</a></li>
      </ul>
    </header>
  </div>

<div class="px-4 py-5 my-5 text-center">
    <img class="d-block mx-auto mb-4" src="icon.png" alt="" height="150">
    <h1 class="display-5 fw-bold">Laravel Fullstack</h1>
    <div class="col-lg-6 mx-auto">
      <p class="lead mb-4">O Framework de desenvolvimento mais robusto e procurado do mercado, pagando salários de até <b>R$ 20.000 </b><i>(vinte mil)</i> / mês, para desenvolvedores Sêniors. 
        Somos a única empresa de ensino e fábrica de software que coloca os alunos dentro de experiências reais, com todos os recursos que vão se deparar no mercado.</p>
        <p>Preço de Lançamento <b>R$ 1.400</b> em até 12x</p>
        <p>Ou <br><b>R$ 900</b> à vista com desconto.</p>
      <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
        <a class="btn btn-success btn-lg px-4 gap-3" href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">Quero fazer parte!</a>
        <a class="btn btn-warning" href="https://chat.whatsapp.com/LmMX0nm4osH4s0kZpNpWg7">Grupo de informações e Venda</a>
      </div>
    </div>
  </div>


<div class="container px-4 py-5" id="icon-grid">
    <h2 class="pb-2 border-bottom">Nossos Diferenciais:</h2>

    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
      <div class="col d-flex align-items-start">
        <img src="cloud1.png" alt="cloud" height="100px">
        <div>
          <h3 class="fw-bold mb-0 fs-4">Servidor por Aluno</h3>
          <p class="bd-callout bd-callout-warning">Seu cursinho só te mostra videos e você não tem acesso a recurso de verdade? Oferecemos 
            a real experiência de subir e gerenciar sua aplicação.</p>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <img src="couch.png" alt="couch" height="100px">
        <div>
          <h3 class="fw-bold mb-0 fs-4">Mentoria</h3>
          <p>Faremos Mentoria para sua carreira, mostrando as vantagens de stacks complementares, vagas e 
            crescimento pessoal.</p>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <img src="checklist.png" alt="couch" height="100px">
        <div>
          <h3 class="fw-bold mb-0 fs-4">Assuntos Periféricos</h3>
          <p>Separamos uma gama de assuntos periféricos que são importantes no cotidiano de um desenvolvedor 
            Laravel.
          </p>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <img src="credit.png" alt="couch" height="100px">
        <div>
          <h3 class="fw-bold mb-0 fs-4">Pagamento facilitado</h3>
          <p>Parcelanos o pagamento em até 12x, em diversas bandeiras</p>
        </div>
      </div>
  </div>

  <div class="row text text-center">
    <div class="col-lg-6">
      <img src="disaster.png" height="80">

      <h2 class="fw-normal">Ambientes</h2>
      <p>Você aprenderá a criar ambientes de homologação e produção, e levantar rapidamente em caso de desastres.</p>
      <!-- <p><a class="btn btn-secondary" href="#">View details »</a></p> -->
    </div>
    <div class="col-lg-6">
        <img src="company.png" height="80">
      <h2 class="fw-normal">Treinamento Empresarial</h2>
      <p >Nossa mentoria é focada em ensinar os processos que ocorem dentro do ambiente corporativo, como Guia de Funções, 
        paths, GitFlow e comunicação Empresarial.</p>
      <!-- <p><a class="btn btn-secondary" href="#">View details »</a></p> -->
    </div>

  @include("bootstrap.footer")

  <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title text-dark" >Reserva de Vagas</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="input" method="post">
          @csrf
          <div class="modal-body">
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label"><kbd>Email:</kbd></label>
              <input type="email" class="form-control" name="email" required>
            </div>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label"><kbd>Nome p/ Certificado:</kbd></label>
              <input type="text" class="form-control" name="nome" required>
            </div>
          </div>  
        
        <div class="modal-footer">
          <input type="reset" class="btn btn-primary" value="Limpar">
          <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Fechar</button>
          <input  type="submit" class="btn btn-success" value="Reservar">
        </form>
        </div>
      </div>
    </div>
  </div>
  <!-- modal -->