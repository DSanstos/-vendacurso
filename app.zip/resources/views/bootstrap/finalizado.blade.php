@extends('bootstrap.model')
  <div class="container">
    <div class="bg-light p-5 rounded mt-3">
        <h1>Cadastro finalizado! </h1>
        <p class="lead">Agora é só aguardar a confirmação de seu pagamento para criarmos Seu usuário no Ambiente EAD.
            Dúvidas e suporte pode Entrar Diretamente no Grupo de membros
        </p>
        <a class="btn btn-lg btn-primary" href="https://chat.whatsapp.com/DsPvM814vSe7XKVBCHbFBg" role="button">Grupo de Alunos »</a>
      </div>
      @include("bootstrap.footer")
  </div>