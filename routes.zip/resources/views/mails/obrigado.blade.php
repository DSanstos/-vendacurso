Agradecemos por seu interesse em nossa turma online de Laravel Fullstack. <br/>
Para ativar sua inscrição é necessário clicar <a href="{{$_SERVER["HTTP_ORIGIN"]}}/ativacao/{{$link}}">aqui</a>