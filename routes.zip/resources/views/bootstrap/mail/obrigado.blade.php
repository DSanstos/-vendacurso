@extends("bootstrap.model")
@section("bodypage")
    obrigado por se Inscrever {{$nome}}!
@endsection